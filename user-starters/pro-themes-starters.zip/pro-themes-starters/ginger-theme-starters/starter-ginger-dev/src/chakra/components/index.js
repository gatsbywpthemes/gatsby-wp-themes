import { Button } from './Button'
import { Input } from './Input'
import { Textarea } from './Textarea'
const CustomComponents = {
  Button,
  Input,
  Textarea,
}
export default CustomComponents
