import { createContext } from 'react'
export const CommentsListContext = createContext()
export const ActiveCommentContext = createContext()
export const SetActiveCommentContext = createContext()
