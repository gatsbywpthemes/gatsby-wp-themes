export const ActivatePrism = () => null
