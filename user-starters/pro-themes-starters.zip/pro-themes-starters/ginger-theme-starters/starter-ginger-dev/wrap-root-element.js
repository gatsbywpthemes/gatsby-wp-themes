import React from 'react'
import SearchWrapper from 'gingerThemeComponents/search/context'

const WrapRootElement = ({ element }) => {
  return <SearchWrapper element={element} />
}
export default WrapRootElement
