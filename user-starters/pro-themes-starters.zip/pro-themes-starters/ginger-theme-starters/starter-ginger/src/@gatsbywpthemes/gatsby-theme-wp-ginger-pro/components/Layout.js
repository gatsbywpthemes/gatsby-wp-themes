import React from "react"
import { Layout as StyledLayout } from "gingerThemeComponents/Layout"
import "../../../styles/style.scss"
export const Layout = (props) => <StyledLayout {...props} />
