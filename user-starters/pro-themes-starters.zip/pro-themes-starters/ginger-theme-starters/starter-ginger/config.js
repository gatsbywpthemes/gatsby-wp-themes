const config = {
  //pathPrefix: "",
  addSiteMap: true,
}
module.exports = config
