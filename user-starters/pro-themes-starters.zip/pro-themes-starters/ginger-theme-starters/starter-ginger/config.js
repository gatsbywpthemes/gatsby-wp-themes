const config = {
  //pathPrefix: "",
}
module.exports = config
