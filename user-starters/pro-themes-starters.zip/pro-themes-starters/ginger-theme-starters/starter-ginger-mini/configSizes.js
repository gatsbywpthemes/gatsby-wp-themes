const sizesSettings = {
  /*
  breakpoints: {
    sm: "37.5em",
    md: "64em",
    lg: "72em",
  },
  */
  sizes: {
    header: ["6rem", "6rem", "6rem"],
    //content: '60rem',
  },
}

export default sizesSettings
