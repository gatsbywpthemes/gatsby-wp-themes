const sizesSettings = {
  /*
  breakpoints: {
    sm: "37.5em",
    md: "64em",
    lg: "72em",
  },
  */
  sizes: {
    header: ["6.75rem", "6.75rem", "5rem"],
    //content: '60rem',
  },
}

export default sizesSettings
