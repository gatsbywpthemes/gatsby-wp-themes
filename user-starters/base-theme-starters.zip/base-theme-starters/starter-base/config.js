const config = {
  //pathPrefix: "",
  layoutWidth: {
    page: "lg",
    post: "lg",
    archive: "md",
  },
}

module.exports = config
