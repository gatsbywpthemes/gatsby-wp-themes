const shadows = {
  hover: '0px 10px 20px rgba(0,0,0,0.45)',
}

export default shadows
