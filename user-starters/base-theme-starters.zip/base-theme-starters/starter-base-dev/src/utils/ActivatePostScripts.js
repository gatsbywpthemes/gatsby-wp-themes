import React from 'react'
import { ActivatePrism } from './ActivatePrism'

export const ActivatePostScripts = () => (
  <>
    <ActivatePrism />
  </>
)
