import { createContext } from 'react'
export const CommentsListContext = createContext()
