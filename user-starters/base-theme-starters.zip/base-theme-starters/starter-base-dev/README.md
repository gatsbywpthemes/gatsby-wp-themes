# Starter Base Dev

[📖 Documentation](https://doc.gatsbywpthemes.com/)

---

## Gatsby WP Themes License

All items purchased separately or in a bundle on Gatsby WP Themes have the same license terms.

You get broad commercial rights. You can use our starters, themes, and plugins to build your personal and commercial projects.
You are not limited in the number of websites that you build.
We also provide updates and support during the period specified on purchase.

Some limitations do apply as stated below:

- You can’t re-sell or re-distribute our items or the derived products based on our items.

That means that you can build an unlimited number of single-end websites for one or different clients. But, on the other hand, you can not open a marketplace where you sell or distribute our items or products based on our items.
